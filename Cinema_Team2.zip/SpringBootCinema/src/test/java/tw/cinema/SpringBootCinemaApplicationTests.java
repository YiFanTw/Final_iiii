package tw.cinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCinemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
